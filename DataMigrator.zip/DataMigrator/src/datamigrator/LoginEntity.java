/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datamigrator;

/**
 *
 * @author hgunes
 */
public class LoginEntity {
    private String dbName;
    private String jdbcAddress;  
    private LoginEntityType type;
    
    public LoginEntity(String dbName, String jdbcAddress, LoginEntityType type){
        this.dbName=dbName;
        this.jdbcAddress=jdbcAddress;
        this.type=type;
    }
    /**
     * @return the dbName
     */
    public String getDbName() {
        return dbName;
    }

    /**
     * @param dbName the dbName to set
     */
    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    /**
     * @return the jdbcAddress
     */
    public String getJdbcAddress() {
        return jdbcAddress;
    }

    /**
     * @param jdbcAddress the jdbcAddress to set
     */
    public void setJdbcAddress(String jdbcAddress) {
        this.jdbcAddress = jdbcAddress;
    }

    /**
     * @return the type
     */
    public LoginEntityType getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(LoginEntityType type) {
        this.type = type;
    }
    
    
}
