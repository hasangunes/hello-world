/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datamigrator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hasan
 */
public class SQLDB {
    
    private String hostname;
    private String instance;
    private String database;
    private String username;
    private String password;
    private String port;
    private Connection con;
    
    public SQLDB(){
        this.hostname = null;
        this.port = null;
        this.instance = null;
        this.database = null;
        this.username = null;
        this.password = null;
        this.con = null;
        
    }
    public SQLDB(String hostname, String port, String instance, String database, String username, String password){
        this.hostname=hostname;
        this.port=port;
        this.instance=instance;
        this.database=database;
        this.username=username;
        this.password=password;
    }
    
    public void connect(){
        try {
            // Establish the connection.
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection("jdbc:sqlserver://"+hostname+":"+port+";instance="+instance+";user="+username+";password="+password);
        }
	// Handle any errors that may have occurred.
	catch (Exception e) {
            e.printStackTrace();
	}
    }
    
    public void disconnect(){
        if (con != null) try { con.close(); } catch(Exception e) {}
    }
    
    public Statement createStatement() throws SQLException{
        return this.con.createStatement();
    }
    
    
    /**
     * @return the hostname
     */
    public String getHostname() {
        return hostname;
    }

    /**
     * @param hostname the hostname to set
     */
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    /**
     * @return the instance
     */
    public String getInstance() {
        return instance;
    }

    /**
     * @param instance the instance to set
     */
    public void setInstance(String instance) {
        this.instance = instance;
    }

    /**
     * @return the database
     */
    public String getDatabase() {
        return database;
    }

    /**
     * @param database the database to set
     */
    public void setDatabase(String database) {
        this.database = database;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the port
     */
    public String getPort() {
        return port;
    }

    /**
     * @param port the port to set
     */
    public void setPort(String port) {
        this.port = port;
    }

    /**
     * @return the con
     */
    public Connection getCon() {
        return con;
    }

    /**
     * @param con the con to set
     */
    public void setCon(Connection con) {
        this.con = con;
    }
    
    
}
